﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SportClub.Models
{
    public class ModelContext : DbContext
    {
        public ModelContext()
            : base("DefaultConnection")
        {

        }
        public DbSet<Client> Clients { get; set; }//клієнти
        public DbSet<Trainer> Trainers { get; set; }// тренера
        public DbSet<Accounting> Accountings { get; set; }//платежі
        public DbSet<Ticket> Tickets { get; set; }//абонементи
        public DbSet<SportHalls> SportHalls { get; set; }//зали

        public DbSet<UserProfile> UserProfiles { get; set; }//юзер
        public DbSet<webpages_Roles> webpages_Roles { get; set; }  // добавляем таблицу ролей    
        public DbSet<Discounts> Discounts { get; set; }// знижки
        public DbSet<PhytobarProducts> PhytobarProducts { get; set; }
        public DbSet<Visits> Visits { get; set; }//відвідування
        public DbSet<UploadFile> UploadFile { get; set; }
        
    }
}